package com.nova.client.module;

import java.util.Arrays;
import java.util.List;

public final class ModeSetting {
    private final String name;
    private final List<String> modes;
    private String value;

    public ModeSetting(String name, String defaultValue, String... modes) {
        if (modes == null || modes.length == 0) throw new IllegalArgumentException("At least one mode is required");
        this.name = name;
        this.modes = List.copyOf(Arrays.asList(modes));
        this.value = this.modes.contains(defaultValue) ? defaultValue : this.modes.get(0);
    }

    public String getName() { return name; }
    public String getValue() { return value; }
    public List<String> getModes() { return modes; }
    public boolean is(String mode) { return value.equalsIgnoreCase(mode); }
    public void setValue(String value) {
        for (String mode : modes) {
            if (mode.equalsIgnoreCase(value)) { this.value = mode; return; }
        }
    }
    public void cycle() {
        int index = modes.indexOf(value);
        value = modes.get((index + 1) % modes.size());
    }
}
