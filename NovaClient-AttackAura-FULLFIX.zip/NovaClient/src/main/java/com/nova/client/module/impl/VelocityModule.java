package com.nova.client.module.impl;

import com.nova.client.module.BooleanSetting;
import com.nova.client.module.Category;
import com.nova.client.module.ModeSetting;
import com.nova.client.module.Module;
import com.nova.client.module.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Anti-knockback. The percent settings are how much of the knockback you KEEP:
 * 0 = no knockback at all, 100 = normal knockback.
 *
 * Vanilla  - exact percent, for HvH.
 * Matrix   - percent with +-8 random noise on every hit.
 * GrimAC   - for servers with a weak Grim setup: its own adjustable ratio (default keeps most of the
 *            knockback), only small noise, never a perfect constant.
 * Neuro    - same as Matrix for now.
 */
public final class VelocityModule extends Module {
    public final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "GrimAC", "Neuro", "Matrix", "Vanilla");

    // Vanilla / Matrix / Neuro ratio
    public final BooleanSetting horizontalEnabled = new BooleanSetting("Horizontal", true);
    public final NumberSetting horizontal = new NumberSetting("Horizontal %", 0.0, 0.0, 100.0, 1.0);
    public final BooleanSetting verticalEnabled = new BooleanSetting("Vertical", true);
    public final NumberSetting vertical = new NumberSetting("Vertical %", 0.0, 0.0, 100.0, 1.0);

    // GrimAC ratio (adjustable knockback rate for the Grim mode)
    public final NumberSetting grimHorizontal = new NumberSetting("Grim Horizontal %", 65.0, 0.0, 100.0, 1.0);
    public final NumberSetting grimVertical = new NumberSetting("Grim Vertical %", 100.0, 0.0, 100.0, 1.0);

    /** Percent of hits that get reduced at all. Below 100 some hits are taken normally. */
    public final NumberSetting chance = new NumberSetting("Chance %", 100.0, 0.0, 100.0, 1.0);

    public final BooleanSetting jumpReset = new BooleanSetting("Jump Reset", true);
    public final NumberSetting jumpResetChance = new NumberSetting("Jump Reset Chance %", 100.0, 0.0, 100.0, 1.0);

    public VelocityModule() {
        super("Velocity", "Reduces or cancels knockback.", Category.COMBAT);
    }

    /** Called from the packet mixin with the velocity the server just gave us. */
    public Vec3d process(Vec3d incoming) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        if (chance.getValue() < 100.0 && rnd.nextDouble(100.0) >= chance.getValue()) return incoming;

        double h, v;
        if (mode.is("GrimAC")) {
            h = clampPercent(grimHorizontal.getValue() + rnd.nextDouble(-3.0, 3.0));
            v = clampPercent(grimVertical.getValue() + rnd.nextDouble(-3.0, 3.0));
        } else {
            h = horizontalEnabled.isEnabled() ? horizontal.getValue() : 100.0;
            v = verticalEnabled.isEnabled() ? vertical.getValue() : 100.0;
            if (!mode.is("Vanilla")) { // Matrix / Neuro: never the exact same percent twice
                h = clampPercent(h + rnd.nextDouble(-8.0, 8.0));
                v = clampPercent(v + rnd.nextDouble(-8.0, 8.0));
            }
        }
        return new Vec3d(incoming.x * h / 100.0, incoming.y * v / 100.0, incoming.z * h / 100.0);
    }

    /** Jump Reset: jump the moment the knockback arrives, if standing on the ground. */
    public boolean shouldJumpReset(ClientPlayerEntity player) {
        if (!jumpReset.isEnabled()) return false;
        if (!player.isOnGround() || player.isTouchingWater() || player.isInLava() || player.isClimbing()) return false;
        return jumpResetChance.getValue() >= 100.0
                || ThreadLocalRandom.current().nextDouble(100.0) < jumpResetChance.getValue();
    }

    private static double clampPercent(double p) { return Math.max(0.0, Math.min(100.0, p)); }
}
