package com.nova.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import org.joml.Matrix4f;

/**
 * Rounded rectangles and circles built from plain GUI quads (the same path DrawContext.fill uses).
 *
 * The old version drew triangle fans with the raw BufferRenderer. Mobile launchers (Pojav / Zalith /
 * MobileGlues, gl4es...) often don't draw those, so every background was invisible and only the
 * text showed. Quads go through vanilla's own GUI render layer, which works everywhere.
 * Shapes are stacked horizontal strips with float coordinates, so edges stay smooth at the real
 * screen resolution. Strips never overlap, so translucent colors stay even.
 */
public final class Draw2D {
    private Draw2D() { }

    public static void roundedRect(DrawContext ctx, float x1, float y1, float x2, float y2, float radius, int color) {
        if (x2 <= x1 || y2 <= y1 || ((color >>> 24) & 255) == 0) return;
        float r = Math.max(0.0F, Math.min(radius, Math.min((x2 - x1) / 2.0F, (y2 - y1) / 2.0F)));

        ctx.draw(); // flush what was queued before, keeps the drawing order right
        VertexConsumer vc = ctx.getVertexConsumers().getBuffer(RenderLayer.getGui());
        Matrix4f m = ctx.getMatrices().peek().getPositionMatrix();

        if (r < 0.5F) {
            quad(vc, m, x1, y1, x2, y2, color);
        } else {
            int rows = Math.max(3, (int) Math.ceil(r * scale()));
            float step = r / rows;
            quad(vc, m, x1, y1 + r, x2, y2 - r, color); // middle block
            for (int i = 0; i < rows; i++) {
                float dy = r - (i + 0.5F) * step; // distance of this strip from the corner circle center
                float inset = r - (float) Math.sqrt(Math.max(0.0F, r * r - dy * dy));
                quad(vc, m, x1 + inset, y1 + i * step, x2 - inset, y1 + (i + 1) * step, color);         // top
                quad(vc, m, x1 + inset, y2 - (i + 1) * step, x2 - inset, y2 - i * step, color);         // bottom
            }
        }
        ctx.draw(); // flush now so text drawn after this stays on top
    }

    public static void circle(DrawContext ctx, float cx, float cy, float radius, int color) {
        if (radius <= 0.0F || ((color >>> 24) & 255) == 0) return;

        ctx.draw();
        VertexConsumer vc = ctx.getVertexConsumers().getBuffer(RenderLayer.getGui());
        Matrix4f m = ctx.getMatrices().peek().getPositionMatrix();

        int rows = Math.max(8, (int) Math.ceil(radius * 2.0F * scale()));
        float step = radius * 2.0F / rows;
        for (int i = 0; i < rows; i++) {
            float y1 = cy - radius + i * step;
            float dy = y1 + step / 2.0F - cy;
            float half = (float) Math.sqrt(Math.max(0.0F, radius * radius - dy * dy));
            quad(vc, m, cx - half, y1, cx + half, y1 + step, color);
        }
        ctx.draw();
    }

    private static float scale() {
        return (float) Math.max(1.0, MinecraftClient.getInstance().getWindow().getScaleFactor());
    }

    private static void quad(VertexConsumer vc, Matrix4f m, float x1, float y1, float x2, float y2, int color) {
        if (x2 <= x1 || y2 <= y1) return;
        vc.vertex(m, x1, y1, 0.0F).color(color);
        vc.vertex(m, x1, y2, 0.0F).color(color);
        vc.vertex(m, x2, y2, 0.0F).color(color);
        vc.vertex(m, x2, y1, 0.0F).color(color);
    }
}
