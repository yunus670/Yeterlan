package com.nova.client.module.impl;

import com.nova.client.module.Category;
import com.nova.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.attackaura.aura.AttackAura;

/**
 * NovaClient adapter for the uploaded AttackAura prototype.
 * TargetESP and TargetHUD use getTarget() to render the selected player.
 */
public final class AuraModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public AuraModule() {
        super("AttackAura", "Targets nearby visible entities and attacks when cooldown is ready.", Category.COMBAT);
    }

    public PlayerEntity getTarget() {
        return AttackAura.getTarget() instanceof PlayerEntity player ? player : null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            AttackAura.clearTarget();
            return;
        }
        // Aura updates are synchronized with movement packet sending by ClientPlayerEntityMixin.
    }

    @Override
    public void onDisable() {
        AttackAura.clearTarget();
    }
}
