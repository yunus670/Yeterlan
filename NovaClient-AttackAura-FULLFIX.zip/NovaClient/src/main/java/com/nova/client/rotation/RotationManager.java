package com.nova.client.rotation;

/**
 * Silent rotation: the rotation sent to the server while the camera stays free.
 * Also holds the "move fix": the direction W moves you in while locked on a target.
 */
public final class RotationManager {
    private static boolean active;
    private static float yaw;
    private static float pitch;

    private static boolean moveFix;
    private static float moveYaw;
    private static boolean forwardOnly;

    private RotationManager() { }

    public static void set(float newYaw, float newPitch) {
        yaw = newYaw;
        pitch = newPitch;
        active = true;
    }

    public static void clear() { active = false; }
    public static boolean isActive() { return active; }
    public static float getYaw() { return yaw; }
    public static float getPitch() { return pitch; }

    public static void setMove(float newMoveYaw, boolean onlyForward) {
        moveYaw = newMoveYaw;
        forwardOnly = onlyForward;
        moveFix = true;
    }

    public static void clearMove() { moveFix = false; forwardOnly = false; }
    public static boolean isMoveFixActive() { return moveFix; }
    public static float getMoveYaw() { return moveYaw; }
    public static boolean isForwardOnly() { return forwardOnly; }
}
